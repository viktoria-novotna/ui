"""Základné pravidlá jednotlivých častí systému: prostredie, senzory, aktuátory, miera úspešnosti."""

import unittest

from zavlazovanie.actuators import AKCIE, Actuators
from zavlazovanie.config import Config
from zavlazovanie.environment import Environment
from zavlazovanie.interface import Action
from zavlazovanie.performance import skore
from zavlazovanie.sensors import Sensors


class TestCastiSystemu(unittest.TestCase):

    def test_polievanie_v_horucave_obari_rastlinu(self):
        e = Environment(Config(pocet_dni=5, min_zdrava=0.0, max_zdrava=100.0))
        e._teplota = 35.0                                     # horúco (nad hranicou 30 °C)
        pred = e._zdravie[(0, 0)]
        e.pridaj_vodu((0, 0), 10.0, 10.0)
        e.dalsi_den()
        self.assertLess(e._zdravie[(0, 0)], pred)
        self.assertEqual(e.vysledky()["dni_sparenia"], 1)

    def test_senzory_davaju_len_cast_pola_a_so_sumom(self):
        c = Config(pocet_senzorov=4, sum_senzora=3.0)
        e = Environment(c)
        senzory = Sensors(e, c)
        vnem = senzory.ziskaj_vnem()
        self.assertEqual(len(vnem.vlhkost), 4)                # len zóny so senzorom
        zona = senzory.zony_so_senzorom[0]
        self.assertNotEqual(vnem.vlhkost[zona], e.vlhkost_zony(zona))   # meranie je zašumené

    def test_zalievanie_zvysi_vlhkost_a_znizi_nadrz(self):
        c = Config()
        e = Environment(c)
        Actuators(e).vykonaj([Action((1, 1), "malo")])
        litre, zvysenie = AKCIE["malo"]
        self.assertEqual(e.nadrz, c.nadrz - litre)
        self.assertEqual(e.vlhkost_zony((1, 1)), c.pociatocna_vlhkost + zvysenie)

    def test_aktuator_nevyda_viac_vody_nez_je_a_ignoruje_neplatne_akcie(self):
        c = Config(nadrz=50.0)
        e = Environment(c)
        n = c.rozmer
        Actuators(e).vykonaj([Action((r, s), "malo") for r in range(n) for s in range(n)])
        self.assertGreaterEqual(e.nadrz, 0.0)                 # nikdy sa nemíňa viac, než je v nádrži
        e2 = Environment(Config())
        Actuators(e2).vykonaj([Action((99, 99), "malo"), Action((0, 0), "obrovsky"),
                               Action((0, 0), "malo"), Action((0, 0), "malo")])
        self.assertEqual(e2.nadrz, 2000.0 - AKCIE["malo"][0])  # vykonala sa len jedna platná akcia

    def test_skore_podla_vzorca(self):
        v = {"uroda": 2000, "voda": 100, "dni_sucha": 10, "dni_prelievania": 5, "dni_sparenia": 0}
        self.assertAlmostEqual(skore(v, w1=0.2, w2=1.0), 2000 - 20 - 15)


if __name__ == "__main__":
    unittest.main()
