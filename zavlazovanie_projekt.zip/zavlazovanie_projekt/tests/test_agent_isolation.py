"""
Oddelenie agenta od prostredia (podmienky z mailu cvičiaceho):
  1. rozhodovacia metóda prijíma vnem, nie prostredie,
  2. vnem je kópia, nie referencia (a nedá sa zmeniť),
  3. agent nemá ako použiť informácie, ktoré vo vneme nie sú.

Spustenie: python3 -m unittest discover tests -v
"""

import inspect
import types
import unittest

from zavlazovanie.agents.baseline_agent import BaselineAgent
from zavlazovanie.agents.smart_agent import SmartAgent
from zavlazovanie.config import Config
from zavlazovanie.environment import Environment
from zavlazovanie.interface import Percept
from zavlazovanie.sensors import Sensors
from zavlazovanie.simulation import Simulation


def prostredie_a_vnem(**parametre):
    c = Config(**parametre)
    e = Environment(c)
    return e, Sensors(e, c).ziskaj_vnem()


class TestOddelenieAgenta(unittest.TestCase):

    def test_vyber_akcie_prijima_vnem_nie_prostredie(self):
        for agent_cls in (BaselineAgent, SmartAgent):
            parametre = [p for p in inspect.signature(agent_cls.vyber_akcie).parameters if p != "self"]
            self.assertEqual(len(parametre), 1)
            self.assertEqual(inspect.signature(agent_cls.vyber_akcie).parameters[parametre[0]].annotation, Percept)

    def test_vnem_je_kopia_nie_referencia(self):
        e, vnem = prostredie_a_vnem(pocet_senzorov=25, sum_senzora=0.0)
        self.assertIsNot(vnem.vlhkost, e._vlhkost)            # nie je to interný slovník prostredia
        zona = next(iter(vnem.vlhkost))
        pred = vnem.vlhkost[zona]
        e.pridaj_vodu(zona, 0.0, 50.0)                        # zmeníme prostredie až po vytvorení vnemu
        self.assertEqual(vnem.vlhkost[zona], pred)            # vnem sa nezmenil
        self.assertNotEqual(e.vlhkost_zony(zona), pred)       # prostredie áno

    def test_vnem_sa_neda_zmenit(self):
        _, vnem = prostredie_a_vnem()
        self.assertIsInstance(vnem.vlhkost, types.MappingProxyType)
        with self.assertRaises(TypeError):
            vnem.vlhkost[next(iter(vnem.vlhkost))] = 999.0
        with self.assertRaises(Exception):
            vnem.nadrz = 0.0                                  # Percept je aj sám „frozen“

    def test_vnem_obsahuje_iba_povolene_udaje(self):
        _, vnem = prostredie_a_vnem()
        self.assertEqual(set(vars(vnem)), {"den", "teplota", "dazd", "nadrz", "vlhkost"})

    def test_agent_nema_odkaz_na_prostredie(self):
        info = Simulation(Config(), SmartAgent).info
        for agent_cls in (BaselineAgent, SmartAgent):
            na_preskumanie, navstivene = [agent_cls(info)], set()
            while na_preskumanie:                             # prejde aj vnorené objekty (napr. SmartAgent.belief)
                x = na_preskumanie.pop()
                if id(x) in navstivene:
                    continue
                navstivene.add(id(x))
                self.assertNotIsInstance(x, Environment)
                if hasattr(x, "__dict__"):
                    na_preskumanie.extend(vars(x).values())


if __name__ == "__main__":
    unittest.main()
