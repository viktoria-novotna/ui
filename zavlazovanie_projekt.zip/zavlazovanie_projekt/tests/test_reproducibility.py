"""Reprodukovateľnosť: rovnaký SEED dá rovnaký beh a zmena parametra sa prejaví vo výsledku."""

import unittest

from zavlazovanie.agents.baseline_agent import BaselineAgent
from zavlazovanie.agents.smart_agent import SmartAgent
from zavlazovanie.config import Config
from zavlazovanie.simulation import Simulation


def odohraj(agent_cls, **parametre):
    return Simulation(Config(**parametre), agent_cls).spusti()


class TestReprodukovatelnost(unittest.TestCase):

    def test_rovnaky_seed_da_rovnaky_vysledok(self):
        for agent_cls in (BaselineAgent, SmartAgent):
            self.assertEqual(odohraj(agent_cls, seed=7), odohraj(agent_cls, seed=7))

    def test_pocasie_nezavisi_od_akcii_agenta(self):
        s1, s2 = Simulation(Config(seed=3), BaselineAgent), Simulation(Config(seed=3), SmartAgent)
        for _ in range(20):                                   # agenti robia rôzne veci, počasie je rovnaké
            v1, _ = s1.krok()
            v2, _ = s2.krok()
            self.assertEqual((v1.teplota, v1.dazd), (v2.teplota, v2.dazd))

    def test_zmena_parametra_ovplyvni_vysledok(self):
        dost_vody = odohraj(SmartAgent, seed=1, nadrz=5000.0)
        malo_vody = odohraj(SmartAgent, seed=1, nadrz=100.0)
        self.assertGreater(dost_vody["skore"], malo_vody["skore"])


if __name__ == "__main__":
    unittest.main()
