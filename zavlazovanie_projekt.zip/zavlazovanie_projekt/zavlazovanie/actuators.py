"""
Aktuátory vykonajú akcie, ktoré agent vybral, a tým zmenia prostredie. Je to jediné
miesto, cez ktoré agent do sveta zasahuje.
"""

from typing import Dict, List, Tuple

from .environment import Environment
from .interface import Action

# Akcie zavlažovania: úroveň -> (litre vody, zvýšenie vlhkosti v %)
AKCIE: Dict[str, Tuple[float, float]] = {
    "malo": (10.0, 10.0),
    "vela": (25.0, 25.0),
}


class Actuators:
    """Preloží akcie agenta na zmeny v prostredí."""

    def __init__(self, environment: Environment):
        self._env = environment

    def vykonaj(self, akcie: List[Action]):
        """Vykoná zoznam akcií. Prázdny zoznam = agent nerobí nič.

        Neplatné akcie (neexistujúca zóna, neznáma úroveň, zóna dvakrát)
        a akcie, na ktoré nestačí voda v nádrži, sa nevykonajú.
        """
        pouzite = set()
        for akcia in akcie:
            zona = akcia.zona
            if (zona not in self._env.zony or akcia.uroven not in AKCIE
                    or zona in pouzite):
                continue
            litre, zvysenie = AKCIE[akcia.uroven]
            if self._env.pridaj_vodu(zona, litre, zvysenie):
                pouzite.add(zona)
