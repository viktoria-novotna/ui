"""
Prostredie: skutočný stav simulovaného poľa a jeho fyzika (vysychanie, dážď, rast plodín)
spolu s generátorom počasia. Prostredie nevie nič o agentovi.

  * Stav smú čítať len senzory (vlastnosti den, teplota, prsi, nadrz, horuco a metóda
    vlhkost_zony).
  * Meniť ho smie len aktuátor (metóda pridaj_vodu).
  * Čas posúva simulácia metódou dalsi_den().
"""

import math
import random
from dataclasses import dataclass
from typing import Dict, Tuple

from .config import Config

Zona = Tuple[int, int]

# Konštanty modelu
ZDRAVIE_PRIRASTOK = 1.0   # zdravie za deň, keď je vlhkosť v poriadku
ZDRAVIE_POKLES = 3.0      # zdravie za deň, keď je sucho alebo prelievanie
DENNY_POKLES = 1.2        # o koľko % denne klesne vlhkosť zóny (vysychanie), rovnako vo všetkých zónach
DAZD_ZVYSENIE = 10.0      # keď prší, vlhkosť každej zóny sa zvýši o 10 %
ODTOK = 4.0               # nadbytočná voda nad zdravým rozsahom odtečie o 4 % denne
SPARENIE = 4.0            # postih za polievanie v horúčave (obarenie), navyše k bežnému poklesu


# ----- počasie ----------------------------------------------------------------

# Počasie má vlastný generátor náhody nezávislý od akcií agenta: pri rovnakom SEEDe je
# vždy rovnaké, takže rôznych agentov možno férovo porovnať.

@dataclass(frozen=True)
class DennePocasie:
    """Počasie jedného dňa: teplota v °C a informácia, či prší."""

    teplota: float
    prsi: bool


class Pocasie:
    """Náhodné počasie: sezónna teplota (najvyššia v strede sezóny) + šum,
    dážď (áno/nie) s danou pravdepodobnosťou."""

    def __init__(self, seed: int, pocet_dni: int, pravd_dazda: float):
        self._rng = random.Random(seed + 1)   # +1: oddelený generátor od zvyšku prostredia
        self._pocet_dni = pocet_dni
        self._pravd_dazda = pravd_dazda

    def dnesne(self, den: int) -> DennePocasie:
        """Vygeneruje počasie pre daný deň. Volá sa raz za deň, v poradí dní."""
        sezona = math.sin(math.pi * den / self._pocet_dni)   # 0 -> 1 -> 0
        teplota = 15.0 + 12.0 * sezona + self._rng.gauss(0.0, 3.0)
        prsi = self._rng.random() < self._pravd_dazda
        return DennePocasie(teplota=teplota, prsi=prsi)


# ----- prostredie -------------------------------------------------------------

class Environment:
    """Skutočný stav sveta. Agent k nemu nemá prístup."""

    def __init__(self, config: Config):
        self.config = config
        self.reset()

    def reset(self):
        """Nastaví prostredie na začiatok sezóny podľa SEEDu."""
        c = self.config
        self._pocasie = Pocasie(c.seed, c.pocet_dni, c.pravd_dazda)

        self.zony = [(r, s) for r in range(c.rozmer) for s in range(c.rozmer)]
        self._vlhkost: Dict[Zona, float] = {z: c.pociatocna_vlhkost for z in self.zony}
        self._zdravie: Dict[Zona, float] = {z: 100.0 for z in self.zony}
        self._nadrz = c.nadrz
        self._den = 0

        self._litre_celkom = 0.0
        self._dni_sucha = 0
        self._dni_prelievania = 0
        self._dni_sparenia = 0
        self._zaliate_za_horuca = set()   # zóny zaliate dnes, keď bolo horúco

        dnes = self._pocasie.dnesne(0)
        self._teplota = dnes.teplota
        self._prsi = dnes.prsi

    # ----- čítanie stavu (používajú senzory) ---------------------------------

    @property
    def den(self) -> int:
        return self._den

    @property
    def teplota(self) -> float:
        return self._teplota

    @property
    def prsi(self) -> bool:
        return self._prsi

    @property
    def nadrz(self) -> float:
        return self._nadrz

    @property
    def horuco(self) -> bool:
        return self._teplota > self.config.horuca_teplota

    def vlhkost_zony(self, zona: Zona) -> float:
        return self._vlhkost[zona]

    def zdravie_zony(self, zona: Zona) -> float:
        """Zdravie zóny (0 - 100). Slúži na zobrazenie (napr. v GUI), nie agentovi."""
        return self._zdravie[zona]

    # ----- zmena stavu (používa aktuátor) -------------------------------------

    def pridaj_vodu(self, zona: Zona, litre: float, zvysenie: float) -> bool:
        """Zaleje zónu. Vráti False, ak v nádrži nie je dosť vody.

        Ak je práve horúco (nad config.horuca_teplota), voda na horúcich listoch
        rastliny obarí a zóna dostane navyše postih na zdravie pri vyhodnotení dňa.
        """
        if litre > self._nadrz:
            return False
        self._nadrz -= litre
        self._litre_celkom += litre
        self._vlhkost[zona] = min(100.0, self._vlhkost[zona] + zvysenie)
        if self.horuco:
            self._zaliate_za_horuca.add(zona)
        return True

    # ----- plynutie času (volá simulácia) -------------------------------------

    def dalsi_den(self):
        """Ukončí aktuálny deň a posunie svet na ďalší (nové počasie, vysychanie)."""
        self._vyhodnot_den()
        self._den += 1
        if not self.skoncilo():
            dnes = self._pocasie.dnesne(self._den)
            self._teplota = dnes.teplota
            self._prsi = dnes.prsi
            self._aplikuj_pocasie()

    def skoncilo(self) -> bool:
        return self._den >= self.config.pocet_dni

    # ----- výsledky pre mieru úspešnosti ---------------------------------------

    def vysledky(self) -> dict:
        """Údaje potrebné na výpočet miery úspešnosti."""
        return {
            "uroda": sum(self._zdravie.values()),
            "voda": self._litre_celkom,
            "dni_sucha": self._dni_sucha,
            "dni_prelievania": self._dni_prelievania,
            "dni_sparenia": self._dni_sparenia,
        }

    # ----- vnútorná dynamika sveta -----------------------------------------------

    def _aplikuj_pocasie(self):
        """Vlhkosť každej zóny denne klesne o DENNY_POKLES a ak prší, zvýši sa
        o DAZD_ZVYSENIE (rovnako vo všetkých zónach). Prebytočná voda nad
        zdravým rozsahom postupne odteká. Teplota vlhkosť neovplyvňuje, slúži
        len na pravidlo o horúčave (obarenie pri polievaní)."""
        for z in self._vlhkost:
            dazd = DAZD_ZVYSENIE if self._prsi else 0.0
            zmena = dazd - DENNY_POKLES
            v = max(0.0, min(100.0, self._vlhkost[z] + zmena))
            if v > self.config.max_zdrava:
                v = max(self.config.max_zdrava, v - ODTOK)
            self._vlhkost[z] = v

    def _vyhodnot_den(self):
        """Na konci dňa aktualizuje zdravie zón podľa ich vlhkosti a prípadného obarenia."""
        c = self.config
        for z, v in self._vlhkost.items():
            if v < c.min_zdrava:
                self._zdravie[z] -= ZDRAVIE_POKLES
                self._dni_sucha += 1
            elif v > c.max_zdrava:
                self._zdravie[z] -= ZDRAVIE_POKLES
                self._dni_prelievania += 1
            else:
                self._zdravie[z] += ZDRAVIE_PRIRASTOK
            if z in self._zaliate_za_horuca:
                self._zdravie[z] -= SPARENIE
                self._dni_sparenia += 1
            self._zdravie[z] = max(0.0, min(100.0, self._zdravie[z]))
        self._zaliate_za_horuca = set()
