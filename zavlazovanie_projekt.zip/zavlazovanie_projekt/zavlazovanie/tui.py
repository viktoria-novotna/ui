"""
Jednoduché textové rozhranie v termináli (vstavaný modul curses, žiadna ďalšia knižnica).
Počas behu zobrazuje mriežku poľa deň po dni podľa VLHKOSTI zón. Na konci sezóny ju
prekreslí podľa FINÁLNEHO ZDRAVIA, aby bolo vidieť, ktoré plodiny prežili a ktoré uschli.

Spustenie:  python3 main.py --gui hard
Ovládanie:  medzerník alebo šípka doprava = ďalší deň, "a" = automatický beh,
            "s" = zastaviť automatický beh, "q" = koniec.
"""

import curses

from .agents.smart_agent import SmartAgent
from .config import Config
from .simulation import Simulation


def _farba_pre_vlhkost(v, min_v, max_v):
    """Vráti číslo farbového páru curses podľa toho, či je zóna suchá,
    v zdravom rozsahu, alebo prelievaná."""
    if v < min_v:
        return 1   # sucho -> červená
    if v > max_v:
        return 2   # prelievanie -> modrá
    return 3       # v poriadku -> zelená


def _znak_pre_vlhkost(v):
    """Znak podľa toho, ako je zóna vlhká (hrubší odtieň = vlhkejšie)."""
    if v < 15:
        return "."
    if v < 30:
        return "o"
    if v < 45:
        return "O"
    if v < 60:
        return "#"
    return "@"


def _farba_pre_zdravie(h):
    """Vráti číslo farbového páru curses podľa finálneho zdravia zóny."""
    if h <= 0:
        return 1   # uschla -> červená
    if h < 70:
        return 4   # trpela -> žltá
    return 3       # prežila zdravá -> zelená


def _znak_pre_zdravie(h):
    """Znak podľa finálneho zdravia zóny (0 - 100)."""
    if h <= 0:
        return "X"    # uschla
    if h < 30:
        return "x"    # takmer uschla
    if h < 70:
        return "o"    # trpela, prežila oslabená
    return "@"        # zdravá


def _spusti_gui(stdscr, nazov_konfiguracie, config: Config, agent_cls=SmartAgent):
    """Hlavná slučka okna: vykresľuje pole, spracúva klávesy a posúva simuláciu po dňoch."""
    curses.curs_set(0)
    curses.start_color()
    curses.use_default_colors()
    curses.init_pair(1, curses.COLOR_RED, -1)
    curses.init_pair(2, curses.COLOR_CYAN, -1)
    curses.init_pair(3, curses.COLOR_GREEN, -1)
    curses.init_pair(4, curses.COLOR_YELLOW, -1)

    sim = Simulation(config, agent_cls)
    e = sim.environment
    n = sim.info.rozmer
    zony_so_senzorom = set(sim.info.zony_so_senzorom)
    min_v, max_v = sim.info.min_zdrava, sim.info.max_zdrava

    auto = False
    posledny_pocet_akcii = 0

    while True:
        stdscr.erase()
        stdscr.addstr(0, 0, f"Zavlažovanie poľa — konfigurácia '{nazov_konfiguracie}', "
                             f"agent {agent_cls.__name__}, SEED {config.seed}", curses.A_BOLD)

        for r in range(n):
            riadok = 2 + r
            for s in range(n):
                zona = (r, s)
                v = e.vlhkost_zony(zona)
                farba = curses.color_pair(_farba_pre_vlhkost(v, min_v, max_v))
                znak = _znak_pre_vlhkost(v)
                stdscr.addstr(riadok, 2 + s * 3, znak + " ", farba | curses.A_BOLD)
                if zona in zony_so_senzorom:
                    stdscr.addstr(riadok, 2 + s * 3 + 1, "*", curses.color_pair(4))

        px = 2 + n * 3 + 3
        stdscr.addstr(2, px, f"Deň: {e.den} / {sim.info.pocet_dni}")
        stdscr.addstr(3, px, f"Teplota: {e.teplota:.1f} °C")
        stdscr.addstr(4, px, f"Prší: {'áno' if e.prsi else 'nie'}")
        if e.horuco:
            stdscr.addstr(4, px + 14, "  PRÍLIŠ HORÚCO, nezalieva sa",
                          curses.color_pair(1) | curses.A_BOLD)
        stdscr.addstr(5, px, f"Nádrž: {e.nadrz:.0f} l")
        v = e.vysledky()
        stdscr.addstr(6, px, f"Úroda zatiaľ: {v['uroda']:.0f}")
        stdscr.addstr(7, px, f"Spotreba vody: {v['voda']:.0f} l")
        stdscr.addstr(8, px, f"Dni sucha: {v['dni_sucha']}")
        stdscr.addstr(9, px, f"Dni prelievania: {v['dni_prelievania']}")
        stdscr.addstr(10, px, f"Dni obarenia: {v['dni_sparenia']}")
        stdscr.addstr(11, px, f"Zaliate zóny dnes: {posledny_pocet_akcii}")

        stdscr.addstr(2 + n + 1, 0, "* = zóna so senzorom   . o O # @ = rastúca vlhkosť")
        stdscr.addstr(2 + n + 2, 0, "červená = sucho   zelená = v poriadku   modrá = prelievanie",
                       curses.A_DIM)
        stdscr.addstr(2 + n + 4, 0,
                       "medzerník/→ = ďalší deň   a = auto beh   s = stop   q = koniec")

        if sim.skoncila():
            # Prekresli mriežku podľa FINÁLNEHO ZDRAVIA zón (nie vlhkosti), aby bolo
            # vidieť, ktoré plodiny prežili a ktoré uschli.
            stdscr.erase()
            stdscr.addstr(0, 0, f"Zavlažovanie poľa — konfigurácia '{nazov_konfiguracie}', "
                                 f"agent {agent_cls.__name__}, SEED {config.seed}   "
                                 f"[VÝSLEDOK SEZÓNY]", curses.A_BOLD)
            prezite = 0
            uschnute = 0
            for r in range(n):
                riadok = 2 + r
                for s in range(n):
                    zona = (r, s)
                    h = e.zdravie_zony(zona)
                    if h <= 0:
                        uschnute += 1
                    else:
                        prezite += 1
                    farba = curses.color_pair(_farba_pre_zdravie(h))
                    znak = _znak_pre_zdravie(h)
                    stdscr.addstr(riadok, 2 + s * 3, znak + "  ", farba | curses.A_BOLD)

            px = 2 + n * 3 + 3
            v = sim.vysledky()   # výsledky vrátane skóre, počtu krokov a dňa vyčerpania nádrže
            stdscr.addstr(2, px, f"Zón spolu: {n * n}")
            stdscr.addstr(3, px, f"Prežilo: {prezite}", curses.color_pair(3) | curses.A_BOLD)
            stdscr.addstr(4, px, f"Uschlo: {uschnute}", curses.color_pair(1) | curses.A_BOLD)
            stdscr.addstr(6, px, f"Úroda: {v['uroda']:.0f}")
            stdscr.addstr(7, px, f"Spotreba vody: {v['voda']:.0f} l")
            stdscr.addstr(8, px, f"Skóre: {v['skore']:.0f}")

            stdscr.addstr(2 + n + 1, 0, "@ = zdravá   o = trpela   x = takmer uschla   X = uschla")
            stdscr.addstr(2 + n + 3, 0, "Sezóna skončila. Stlač q pre koniec.", curses.A_BOLD)
            stdscr.refresh()
            while stdscr.getch() != ord("q"):
                pass
            return v, sim.priebeh

        stdscr.refresh()

        if auto:
            stdscr.timeout(150)
            klaves = stdscr.getch()
            if klaves == -1:
                _, akcie = sim.krok()
                posledny_pocet_akcii = len(akcie)
                continue
        else:
            stdscr.timeout(-1)
            klaves = stdscr.getch()

        if klaves == ord("q"):
            return None
        elif klaves == ord("a"):
            auto = True
        elif klaves == ord("s"):
            auto = False
        elif klaves in (ord(" "), curses.KEY_RIGHT):
            _, akcie = sim.krok()
            posledny_pocet_akcii = len(akcie)


def spusti(nazov_konfiguracie: str, config: Config, agent_cls=SmartAgent):
    """Vstupný bod volaný z main.py. Vráti dvojicu (výsledky, priebeh po dňoch)
    alebo None, ak sa program ukončil cez 'q' pred koncom sezóny."""
    return curses.wrapper(_spusti_gui, nazov_konfiguracie, config, agent_cls)
