"""
Vlastný inteligentný agent. Súbor obsahuje dve triedy:

  * Belief     - pamäť agenta: odhad vlhkosti každej zóny (aj tých bez senzora), naučená
                 rýchlosť vysychania a plán, ktoré zóny sa pri danej zásobe vody dajú
                 udržať zdravé do konca sezóny,
  * SmartAgent - z toho, čo agent vie, vyberá, ktoré zóny zaliať.

Každý deň agent aktualizuje pamäť podľa dnešného vnemu, naplánuje, ktoré zóny sa oplatí
udržať zdravé, a zaleje tie, ktorým by zajtra hrozilo sucho. Keď je príliš horúco,
nezaleje nič, aby rastliny neobaril. Agent dostane len AgentInfo a vnem, nikdy prostredie.
"""

from typing import Dict, List, Set, Tuple

from ..interface import Action, AgentInfo, Percept, Zona


class Belief:
    """Vnútorný stav agenta: odhad[zona] a pokles vlhkosti za deň."""

    K = 0.4                  # váha merania pri oprave odhadu (0 = ignoruj, 1 = len meranie)
    ALFA = 0.05               # rýchlosť učenia poklesu vlhkosti
    ZACIATOCNY_POKLES = 1.0   # počiatočný (zámerne nepresný) odhad poklesu (%/deň), agent sa učí skutočnú hodnotu
    DAZD_ZVYSENIE = 10.0      # znalosť dodaná vopred: o koľko približne zvýši vlhkosť dážď

    def __init__(self, info: AgentInfo):
        self.info = info
        self.zony = [(r, s) for r in range(info.rozmer) for s in range(info.rozmer)]
        stred = (info.min_zdrava + info.max_zdrava) / 2
        self.odhad: Dict[Zona, float] = {z: stred for z in self.zony}
        self.pokles = self.ZACIATOCNY_POKLES

        self.aktivne: Set[Zona] = set(self.zony)   # zóny, ktoré sa plán snaží udržať zdravé
        self._dni_pozorovani = 0
        self._dni_dazda = 0

        self._prvy_den = True
        self._minule_merania: Dict[Zona, float] = {}
        self._minule_zalievanie: Dict[Zona, float] = {}

    # ----- aktualizácia na základe dnešného vnemu ---------------------------

    def aktualizuj(self, percept: Percept):
        """Posunie odhad o pokles a dážď, opraví ho meraním a naučí sa presnejší pokles."""
        self._dni_pozorovani += 1
        self._dni_dazda += 1 if percept.dazd else 0

        if self._prvy_den:
            self._oprav_meraniami(percept, posunuty=dict(self.odhad))
            self._prvy_den = False
            return

        dazd = self.DAZD_ZVYSENIE if percept.dazd else 0.0

        pozorovania = []
        for z, m in percept.vlhkost.items():
            if z in self._minule_merania:
                zal = self._minule_zalievanie.get(z, 0.0)
                pozorovania.append(self._minule_merania[z] + zal + dazd - m)
        bezpecne = all(5.0 < o < 95.0 for o in self.odhad.values())
        if pozorovania and bezpecne:
            priemer = sum(pozorovania) / len(pozorovania)
            self.pokles += self.ALFA * (priemer - self.pokles)

        posunuty = {z: min(100.0, max(0.0, v - self.pokles + dazd))
                     for z, v in self.odhad.items()}
        self._oprav_meraniami(percept, posunuty)

    def _oprav_meraniami(self, percept: Percept, posunuty: Dict[Zona, float]):
        """Opraví posunutý odhad zašumenými meraniami (vyhladzuje šum)."""
        merania = percept.vlhkost
        rezidua = [m - posunuty[z] for z, m in merania.items()]
        priemerne_rezidum = sum(rezidua) / len(rezidua) if rezidua else 0.0

        for z in self.zony:
            if z in merania:
                self.odhad[z] = posunuty[z] + self.K * (merania[z] - posunuty[z])
            else:
                # Zóna bez senzora: chyby modelu sú spoločné pre celé pole,
                # preto použije priemernú chybu zo všetkých senzorov
                self.odhad[z] = posunuty[z] + self.K * priemerne_rezidum
            self.odhad[z] = min(100.0, max(0.0, self.odhad[z]))

    def zapamataj(self, percept: Percept, zalievanie: Dict[Zona, float]):
        """Zapamätá si dnešné merania a zalievanie, aby mohol zajtra správne posunúť odhad,
        a rovno premietne zalievanie do odhadu."""
        for z, zvysenie in zalievanie.items():
            self.odhad[z] += zvysenie
        self._minule_merania = dict(percept.vlhkost)
        self._minule_zalievanie = zalievanie

    # ----- plánovanie vody ---------------------------------------------------

    def planuj_aktivne_zony(self, percept: Percept, litre_na_percento: float, zasoba_istota: float):
        """Rozhodne, koľko zón zvládne do konca sezóny udržať pri zásobe vody.

        Odhadne dennú spotrebu vody na jednu zónu (pokles vlhkosti znížený o
        priemerný účinok dažďa, ktorý sa učí z pozorovaného počtu daždivých dní)
        a z toho, koľko vody zostáva a koľko dní ostáva, vypočíta počet zón.
        Ak vody nestačí na všetky, sústredí ju na zóny s najvyššou vlhkosťou,
        lebo sa im udržiava najlacnejšie.
        """
        dni_ostava = max(1, self.info.pocet_dni - percept.den)
        p_dazda = (self._dni_dazda + 0.8) / (self._dni_pozorovani + 10.0)
        potreba = max(0.3, self.pokles - p_dazda * self.DAZD_ZVYSENIE)   # % na zónu a deň
        litre_na_zonu = dni_ostava * potreba * litre_na_percento
        pocet = int(zasoba_istota * percept.nadrz / litre_na_zonu)
        pocet = max(1, min(len(self.zony), pocet))

        # Už aktívne zóny majú prednosť, aby sa plán zbytočne nemenil
        poradie = sorted(self.zony, key=lambda z: (z not in self.aktivne, -self.odhad[z]))
        self.aktivne = set(poradie[:pocet])


class SmartAgent:
    """Agent s vnútorným modelom poľa (pamäť), učením a plánovaním vody."""

    REZERVA = 4.0          # bezpečnostná rezerva nad dolnou hranicou (%)
    HORNA_REZERVA = 4.0    # nezalievať, ak by vlhkosť prekročila max - rezerva
    ZASOBA_ISTOTA = 2.5    # plánuje s optimistickejšou zásobou (dážď časť vody ušetrí; overené pokusmi)

    def __init__(self, info):
        self.info = info
        self.belief = Belief(info)

    def vyber_akcie(self, percept: Percept) -> List[Action]:
        """Aktualizuje pamäť podľa dnešného vnemu, vyberie zóny na zaliatie a zapamätá si, čo urobil."""
        self.belief.aktualizuj(percept)
        akcie, zalievanie = self._rozhodni(percept)
        self.belief.zapamataj(percept, zalievanie)
        return akcie

    def _rozhodni(self, percept: Percept) -> Tuple[List[Action], Dict[Zona, float]]:
        """Vyberie zóny, ktoré treba zaliať, podľa presvedčenia (Belief).

        Keď je príliš horúco, agent nezaleje nič, aby vodou rastliny neobaril,
        a počká na chladnejší deň.
        """
        if percept.teplota > self.info.horuca_teplota:
            return [], {}

        min_v = self.info.min_zdrava
        max_v = self.info.max_zdrava
        litre_malo, zvys_malo = self.info.akcie["malo"]
        litre_vela, zvys_vela = self.info.akcie["vela"]
        nadrz = percept.nadrz
        b = self.belief

        b.planuj_aktivne_zony(percept, litre_malo / zvys_malo, self.ZASOBA_ISTOTA)

        # Zóny, ktorým by zajtra hrozilo sucho (od najsuchších)
        kandidati = [z for z in b.aktivne
                     if b.odhad[z] - b.pokles < min_v + self.REZERVA]
        kandidati.sort(key=lambda z: b.odhad[z])

        akcie: List[Action] = []
        zalievanie: Dict[Zona, float] = {}
        for z in kandidati:
            if b.odhad[z] > max_v - self.HORNA_REZERVA - zvys_malo:
                continue                     # hrozilo by prelievanie
            if b.odhad[z] < min_v - 10 and b.odhad[z] + zvys_vela < max_v - self.HORNA_REZERVA:
                uroven, litre, zvys = "vela", litre_vela, zvys_vela
            else:
                uroven, litre, zvys = "malo", litre_malo, zvys_malo
            if litre > nadrz:
                continue                     # nedostatok vody
            nadrz -= litre
            akcie.append(Action(z, uroven))
            zalievanie[z] = zvys
        return akcie, zalievanie
