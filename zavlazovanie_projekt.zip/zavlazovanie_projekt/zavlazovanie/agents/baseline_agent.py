"""
Základný agent, s ktorým porovnávame inteligentného agenta. Dostane len AgentInfo
(pri vytvorení) a vnem (každý deň), nikdy prostredie.
"""

from typing import List

from ..interface import Action, AgentInfo, Percept


class BaselineAgent:
    """Jednoduchý agent bez pamäte a bez reakcie na vnem.

    Pravidlo: každý deň zaleje všetky zóny malým množstvom vody, bez ohľadu
    na namerané hodnoty. Nepozná zásobu vody ani históriu.
    """

    def __init__(self, info: AgentInfo):
        self.info = info

    def vyber_akcie(self, percept: Percept) -> List[Action]:
        n = self.info.rozmer
        return [Action((r, s), "malo") for r in range(n) for s in range(n)]
