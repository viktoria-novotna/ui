"""
Riadi priebeh sezóny a spája všetkých päť častí systému. Jeden deň prebehne takto:

    senzory vyrobia vnem -> agent vyberie akcie -> aktuátory ich vykonajú -> prostredie sa posunie o deň

Agent nikdy nedostane odkaz na prostredie, iba AgentInfo a vnem. Simulácia popri tom
zapisuje priebeh behu (jeden riadok za deň, atribút `priebeh`) a deň, v ktorom sa minula
voda (`den_vycerpania_nadrze`). Záznam je len pozorovateľ pre log a grafy: číta skutočný
stav prostredia, ale agentovi sa tieto údaje nepredávajú.
"""

from typing import List, Tuple

from .actuators import AKCIE, Actuators
from .config import Config
from .environment import Environment
from .interface import Action, AgentInfo, Percept
from .performance import skore
from .sensors import Sensors


class Simulation:
    """Jeden beh sezóny: prostredie, senzory, aktuátory a agent dokopy."""

    def __init__(self, config: Config, agent_cls):
        """Vytvorí všetky časti systému. Agentovi odovzdá len AgentInfo, nikdy prostredie."""
        self.environment = Environment(config)
        self.sensors = Sensors(self.environment, config)
        self.actuators = Actuators(self.environment)

        self.info = AgentInfo(
            rozmer=config.rozmer,
            pocet_dni=config.pocet_dni,
            zony_so_senzorom=tuple(self.sensors.zony_so_senzorom),
            min_zdrava=config.min_zdrava,
            max_zdrava=config.max_zdrava,
            horuca_teplota=config.horuca_teplota,
            akcie=dict(AKCIE),
        )
        self.agent = agent_cls(self.info)

        self._pocet_dni = config.pocet_dni
        self._najlacnejsia_akcia = min(litre for litre, _ in AKCIE.values())
        self.den_vycerpania_nadrze = None   # po koľkých dňoch sa minula voda (None = ešte nie)
        self.priebeh: List[dict] = []       # záznam behu: jeden riadok za každý deň

    def skoncila(self) -> bool:
        return self.environment.skoncilo()

    def krok(self) -> Tuple[Percept, List[Action]]:
        """Odohrá jeden deň a vráti vnem, ktorý agent dostal, a akcie, ktoré vybral."""
        e = self.environment
        percept = self.sensors.ziskaj_vnem()

        # Skutočný stav na začiatku dňa — len pre záznam priebehu (agent ho nedostane).
        pocet_zon = len(e.zony)
        skutocna_vlhkost = sum(e.vlhkost_zony(z) for z in e.zony) / pocet_zon
        zdravie = sum(e.zdravie_zony(z) for z in e.zony) / pocet_zon

        akcie = self.agent.vyber_akcie(percept)
        self.actuators.vykonaj(akcie)

        merania = list(percept.vlhkost.values())
        self.priebeh.append({
            "den": percept.den,
            "teplota": round(percept.teplota, 1),
            "dazd": int(percept.dazd),
            "nadrz_na_zaciatku": round(percept.nadrz, 1),
            "pocet_akcii": len(akcie),
            "litre_dnes": round(percept.nadrz - e.nadrz, 1),
            "priemer_namerana_vlhkost": round(sum(merania) / len(merania), 1) if merania else "",
            "priemer_skutocna_vlhkost": round(skutocna_vlhkost, 1),
            "priemerne_zdravie": round(zdravie, 1),
        })

        e.dalsi_den()
        if self.den_vycerpania_nadrze is None and e.nadrz < self._najlacnejsia_akcia:
            self.den_vycerpania_nadrze = e.den
        return percept, akcie

    def vysledky(self) -> dict:
        """Výsledky behu vrátane skóre, počtu krokov a dňa vyčerpania nádrže.

        `den_vycerpania_nadrze` je počet dní, ktoré vydržala voda v nádrži
        (voda klesla pod cenu najlacnejšej akcie). Ak vydržala celú sezónu,
        je to dĺžka sezóny.
        """
        v = self.environment.vysledky()
        v["skore"] = skore(v)
        v["kroky"] = self.environment.den
        v["den_vycerpania_nadrze"] = (self.den_vycerpania_nadrze
                                      if self.den_vycerpania_nadrze is not None
                                      else self._pocet_dni)
        return v

    def spusti(self) -> dict:
        """Odohrá celú sezónu a vráti jej výsledky aj so skóre."""
        while not self.skoncila():
            self.krok()
        return self.vysledky()
