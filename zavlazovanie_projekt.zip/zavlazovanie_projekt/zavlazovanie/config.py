"""
Parametre simulácie. Hodnoty sú v súbore konfiguracie.json: záznam "default" obsahuje
základné nastavenie a záznamy "easy", "medium" a "hard" ho prepisujú pre jednotlivé
úrovne náročnosti. Novú úroveň stačí pridať do súboru, kód sa nemení.
"""

import json
import os
from dataclasses import dataclass, fields

KONFIGURACIE_SUBOR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "konfiguracie.json")

# Zobrazovacie poradie známych úrovní (ostatné nasledujú abecedne)
PORADIE_KONFIGURACII = ("easy", "medium", "hard")


@dataclass
class Config:
    """Všetky nastaviteľné parametre jedného experimentu."""

    seed: int = 42                  # náhodný SEED (rovnaký seed = rovnaký experiment)
    rozmer: int = 5                 # pole je rozmer x rozmer zón
    pocet_dni: int = 90             # dĺžka sezóny
    nadrz: float = 2000.0           # začiatočná zásoba vody v litroch
    pocet_senzorov: int = 6         # v koľkých zónach je senzor vlhkosti
    sum_senzora: float = 3.0        # smerodajná odchýlka šumu merania (v %)
    pravd_dazda: float = 0.08       # pravdepodobnosť dažďa v jednom dni
    min_zdrava: float = 30.0        # dolná hranica zdravej vlhkosti (%)
    max_zdrava: float = 60.0        # horná hranica zdravej vlhkosti (%)
    pociatocna_vlhkost: float = 45.0
    horuca_teplota: float = 30.0    # nad touto teplotou (°C) polievanie obarí rastliny

    def s(self, **zmeny) -> "Config":
        """Vráti kópiu konfigurácie s pozmenenými hodnotami (napr. iný SEED)."""
        return Config(**{**self.__dict__, **zmeny})


def _nacitaj_subor() -> dict:
    with open(KONFIGURACIE_SUBOR, encoding="utf-8") as f:
        return json.load(f)


def nacitaj_config(nazov: str) -> Config:
    """Vráti Config pre danú úroveň (napr. "hard"): hodnoty z "default" prepísané hodnotami úrovne."""
    data = _nacitaj_subor()
    if nazov == "default" or nazov not in data:
        raise ValueError(f"Neznáma konfigurácia '{nazov}'. Dostupné: {zoznam_konfiguracii()}")
    hodnoty = {**data.get("default", {}), **data[nazov]}
    nezname = set(hodnoty) - {f.name for f in fields(Config)}
    if nezname:
        raise ValueError(f"Neznáme polia v konfigurácii '{nazov}': {sorted(nezname)}")
    return Config(**hodnoty)


def zoznam_konfiguracii():
    """Názvy všetkých úrovní v konfiguracie.json okrem "default": easy, medium, hard, potom ostatné abecedne."""
    nazvy = [n for n in _nacitaj_subor() if n != "default"]
    return sorted(nazvy, key=lambda n: (PORADIE_KONFIGURACII.index(n) if n in PORADIE_KONFIGURACII
                                        else len(PORADIE_KONFIGURACII), n))
