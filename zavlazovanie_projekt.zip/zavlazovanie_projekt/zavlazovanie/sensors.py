"""
Senzory sprostredkúvajú agentovi svet. Prečítajú skutočný stav prostredia, vyberú z neho
len časť (vlhkosť iba v niektorých zónach), pridajú k nej šum a výsledok odovzdajú
agentovi ako vnem. Agent dostane iba tento vnem, nikdy samotné prostredie.
"""

import random
from typing import List, Tuple

from .config import Config
from .environment import Environment
from .interface import Percept, Zona


class Sensors:
    """Vyrába vnem pre agenta zo skutočného stavu prostredia."""

    def __init__(self, environment: Environment, config: Config):
        """Náhodne (podľa SEEDu) vyberie zóny so senzorom a pripraví generátor šumu."""
        self._env = environment
        self._sum = config.sum_senzora

        n = min(config.pocet_senzorov, len(environment.zony))
        self.zony_so_senzorom: List[Zona] = sorted(
            random.Random(config.seed).sample(environment.zony, n)
        )
        self._rng_sum = random.Random(config.seed + 2)

    def ziskaj_vnem(self) -> Percept:
        """Vnem pre agenta: zašumená vlhkosť v zónach so senzorom, teplota,
        dážď (áno/nie), zostávajúca voda a číslo dňa."""
        e = self._env
        merania = {}
        for z in self.zony_so_senzorom:
            chyba = self._rng_sum.gauss(0.0, self._sum)
            merania[z] = max(0.0, min(100.0, e.vlhkost_zony(z) + chyba))

        return Percept(
            den=e.den,
            teplota=e.teplota,
            dazd=e.prsi,
            nadrz=e.nadrz,
            vlhkost=merania,
        )
