"""
Spúšťa experimenty, v ktorých sa základný a inteligentný agent porovnávajú na viacerých
SEEDoch v každej úrovni náročnosti z konfiguracie.json. Súbor obsahuje aj zápis výsledkov
(log a CSV) a kreslenie grafu.

Výstupy sa ukladajú do priečinka results/:
    behy.csv          - výsledok každého jedného behu (vrátane času a dňa vyčerpania nádrže)
    priebeh.csv       - priebeh každého behu deň po dni
    suhrn.csv         - priemer a smerodajná odchýlka pre každú dvojicu (úroveň, agent)
    graf_skore.png    - porovnanie agentov podľa skóre
    log.txt           - záznam všetkých behov
    priebeh_demo.csv  - priebeh behu spusteného cez --demo
    gui_vysledky.csv, gui_priebeh.csv - výsledky a priebeh behov spustených cez --gui
"""

import csv
import logging
import os
import statistics
import time

from .agents.baseline_agent import BaselineAgent
from .agents.smart_agent import SmartAgent
from .config import Config, nacitaj_config, zoznam_konfiguracii
from .simulation import Simulation

AGENTI = {
    "baseline": BaselineAgent,
    "smart": SmartAgent,
}

POCET_BEHOV = 20   # počet opakovaní každej konfigurácie
PRVY_SEED = 1       # behy používajú SEEDy PRVY_SEED, PRVY_SEED + 1, ...

# Veličiny, z ktorých sa počíta priemer a smerodajná odchýlka
METRIKY = ("skore", "uroda", "voda", "dni_sucha", "dni_prelievania", "dni_sparenia",
           "den_vycerpania_nadrze", "cas_ms")


# ---------------------------------------------------------------------------
# Záznam výsledkov: log (log.txt) a CSV súbory v priečinku results/
# ---------------------------------------------------------------------------

VYSTUP = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "results")


def zapni_logovanie(nazov_suboru: str = "log.txt"):
    """Presmeruje logovanie do súboru v priečinku results/."""
    os.makedirs(VYSTUP, exist_ok=True)
    logging.basicConfig(filename=os.path.join(VYSTUP, nazov_suboru), filemode="w",
                        level=logging.INFO, format="%(asctime)s %(message)s")


def zaznamenaj_beh(konfiguracia: str, agent: str, seed: int, vysledky: dict):
    """Zapíše výsledok jedného behu ako jeden riadok do logu."""
    logging.info("konf=%s agent=%s seed=%d uroda=%.0f voda=%.0f sucho=%d prelievanie=%d "
                 "sparenie=%d skore=%.0f nadrz_vydrzala_dni=%d cas_ms=%.2f",
                 konfiguracia, agent, seed,
                 vysledky["uroda"], vysledky["voda"], vysledky["dni_sucha"],
                 vysledky["dni_prelievania"], vysledky["dni_sparenia"], vysledky["skore"],
                 vysledky["den_vycerpania_nadrze"], vysledky.get("cas_ms", 0.0))


def zapis_csv(nazov_suboru: str, riadky: list):
    """Zapíše riadky do CSV v priečinku results/ (existujúci súbor prepíše) a vráti cestu k nemu."""
    os.makedirs(VYSTUP, exist_ok=True)
    cesta = os.path.join(VYSTUP, nazov_suboru)
    with open(cesta, "w", newline="", encoding="utf-8") as f:
        pisar = csv.DictWriter(f, fieldnames=list(riadky[0].keys()))
        pisar.writeheader()
        pisar.writerows(riadky)
    return cesta


def pripoj_riadky_csv(nazov_suboru: str, riadky: list):
    """Pridá riadky na koniec CSV. Ak súbor neexistuje, vytvorí ho s hlavičkou.

    Ak má existujúci súbor inú hlavičku (napr. zo staršej verzie programu),
    súbor sa prepíše so spoločnou hlavičkou, aby sa stĺpce nikdy nepomiešali.
    """
    os.makedirs(VYSTUP, exist_ok=True)
    cesta = os.path.join(VYSTUP, nazov_suboru)
    if not riadky:
        return cesta
    polia = list(riadky[0].keys())

    if not os.path.exists(cesta):
        with open(cesta, "w", newline="", encoding="utf-8") as f:
            pisar = csv.DictWriter(f, fieldnames=polia)
            pisar.writeheader()
            pisar.writerows(riadky)
        return cesta

    with open(cesta, newline="", encoding="utf-8") as f:
        citac = csv.DictReader(f)
        stare_polia = list(citac.fieldnames or [])
        stare_riadky = list(citac) if stare_polia != polia else None

    if stare_riadky is None:   # rovnaká hlavička -> stačí pridať
        with open(cesta, "a", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, fieldnames=polia).writerows(riadky)
        return cesta

    vsetky_polia = stare_polia + [p for p in polia if p not in stare_polia]
    with open(cesta, "w", newline="", encoding="utf-8") as f:
        pisar = csv.DictWriter(f, fieldnames=vsetky_polia, restval="")
        pisar.writeheader()
        pisar.writerows(stare_riadky)
        pisar.writerows(riadky)
    return cesta


def pripoj_csv(nazov_suboru: str, riadok: dict):
    """Pridá jeden riadok do CSV (napr. výsledok jedného GUI behu)."""
    return pripoj_riadky_csv(nazov_suboru, [riadok])


# ---------------------------------------------------------------------------
# Graf výsledkov
# ---------------------------------------------------------------------------

# Farby stĺpcov: základný agent ružová, inteligentný agent modrá
FARBY = ("#EC6FA9", "#3E7CC0")


def nakresli_graf(suhrn: list, konfiguracie: list, nazov_suboru: str = "graf_skore.png"):
    """Stĺpcový graf priemerného skóre agentov v jednotlivých konfiguráciách."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib nie je nainštalovaný, graf sa nevytvorí (pip install matplotlib).")
        return None

    os.makedirs(VYSTUP, exist_ok=True)
    cesta = os.path.join(VYSTUP, nazov_suboru)

    sirka = 0.38
    fig, os_ = plt.subplots(figsize=(8, 4.5))
    for i, (agent, popis) in enumerate([("baseline", "Základný agent"),
                                        ("smart", "Inteligentný agent")]):
        riadky = [next(r for r in suhrn if r["konfiguracia"] == k and r["agent"] == agent)
                  for k in konfiguracie]
        polohy = [j + (i - 0.5) * sirka for j in range(len(konfiguracie))]
        os_.bar(polohy, [r["skore_priemer"] for r in riadky], sirka, color=FARBY[i],
                yerr=[r["skore_sd"] for r in riadky], capsize=4, label=popis)
    os_.axhline(0, color="black", linewidth=0.8)
    os_.set_xticks(range(len(konfiguracie)))
    os_.set_xticklabels(konfiguracie)
    os_.set_ylabel("skóre (priemer ± smerodajná odchýlka)")
    os_.set_title("Porovnanie agentov v jednotlivých konfiguráciách prostredia")
    os_.legend()
    fig.tight_layout()
    fig.savefig(cesta, dpi=150)
    plt.close(fig)
    return cesta


# ---------------------------------------------------------------------------
# Jeden beh
# ---------------------------------------------------------------------------

def spusti_beh(agent_cls, config: Config, seed: int):
    """Odohrá jednu sezónu. Vráti dvojicu (výsledky, priebeh).

    výsledky: surové dáta behu vrátane skóre, počtu krokov, dňa vyčerpania nádrže
              a času výpočtu v milisekundách (cas_ms),
    priebeh:  zoznam riadkov, jeden za každý deň sezóny.
    """
    zaciatok = time.perf_counter()
    sim = Simulation(config.s(seed=seed), agent_cls)
    vysledky = sim.spusti()
    vysledky["cas_ms"] = round((time.perf_counter() - zaciatok) * 1000, 2)
    return vysledky, sim.priebeh


def demo(nazov_konfiguracie: str, seed: int):
    """Vypíše jeden beh inteligentného agenta deň po dni a uloží ho do results/priebeh_demo.csv."""
    config = nacitaj_config(nazov_konfiguracie).s(seed=seed)
    sim = Simulation(config, SmartAgent)
    print(f"Demo: konfigurácia '{nazov_konfiguracie}', seed {seed}")
    print(f"{'deň':>4} {'°C':>5} {'dážď':>5} {'nádrž':>7} {'priem. meranie':>15} {'zaliate zóny':>13}")
    while not sim.skoncila():
        percept, akcie = sim.krok()
        merania = list(percept.vlhkost.values())
        priemer = sum(merania) / len(merania)
        print(f"{percept.den:>4} {percept.teplota:>5.1f} {'áno' if percept.dazd else 'nie':>5} "
              f"{percept.nadrz:>7.0f} {priemer:>15.1f} {len(akcie):>13}")
    v = sim.vysledky()
    print(f"Úroda {v['uroda']:.0f}, voda {v['voda']:.0f} l, dni sucha {v['dni_sucha']}, "
          f"dni prelievania {v['dni_prelievania']}, dni sparenia {v['dni_sparenia']}, "
          f"skóre {v['skore']:.0f}, nádrž vydržala {v['den_vycerpania_nadrze']} dní")
    riadky = [{"konfiguracia": nazov_konfiguracie, "agent": "smart", "seed": seed, **r}
              for r in sim.priebeh]
    print(f"Priebeh behu (deň po dni) uložený do: {zapis_csv('priebeh_demo.csv', riadky)}")


# ---------------------------------------------------------------------------
# Súhrnný experiment
# ---------------------------------------------------------------------------

def priemer_a_odchylka(hodnoty):
    return statistics.mean(hodnoty), (statistics.stdev(hodnoty) if len(hodnoty) > 1 else 0.0)


def spusti_experiment(pocet_behov: int = POCET_BEHOV, nazvy_konfiguracii=None):
    """Odohrá všetky úrovne, oboch agentov a všetky SEEDy, uloží výsledky, súhrn a graf a vypíše súhrnnú tabuľku."""
    zapni_logovanie()
    nazvy_konfiguracii = nazvy_konfiguracii or zoznam_konfiguracii()

    behy = []       # všetky jednotlivé behy (surové výsledky)
    priebehy = []   # priebeh všetkých behov deň po dni
    suhrn = []      # súhrn pre každú dvojicu (konfigurácia, agent)
    seedy = range(PRVY_SEED, PRVY_SEED + pocet_behov)

    for nazov_konf in nazvy_konfiguracii:
        config = nacitaj_config(nazov_konf)
        for nazov_agenta, agent_cls in AGENTI.items():
            vysledky = []
            for seed in seedy:            # rovnaké SEEDy pre oboch agentov
                v, priebeh = spusti_beh(agent_cls, config, seed)
                vysledky.append(v)
                identita = {"konfiguracia": nazov_konf, "agent": nazov_agenta, "seed": seed}
                behy.append({**identita, **v})
                priebehy.extend({**identita, **r} for r in priebeh)
                zaznamenaj_beh(nazov_konf, nazov_agenta, seed, v)

            riadok = {"konfiguracia": nazov_konf, "agent": nazov_agenta, "pocet_behov": len(vysledky)}
            for kluc in METRIKY:
                m, sd = priemer_a_odchylka([v[kluc] for v in vysledky])
                riadok[kluc + "_priemer"] = round(m, 2)
                riadok[kluc + "_sd"] = round(sd, 2)
            suhrn.append(riadok)

    zapis_csv("behy.csv", behy)
    zapis_csv("priebeh.csv", priebehy)
    zapis_csv("suhrn.csv", suhrn)
    vypis_tabulku(suhrn)
    nakresli_graf(suhrn, nazvy_konfiguracii)
    print("\nVýsledky uložené v priečinku results/: behy.csv, priebeh.csv, suhrn.csv, "
          "graf_skore.png, log.txt")


def zaznamenaj_gui_beh(nazov_konfiguracie: str, seed: int, vysledky: dict, nazov_agenta: str = "smart"):
    """Pridá výsledok jedného behu spusteného cez --gui do gui_vysledky.csv."""
    riadok = {"konfiguracia": nazov_konfiguracie, "agent": nazov_agenta, "seed": seed, **vysledky}
    return pripoj_csv("gui_vysledky.csv", riadok)


def zaznamenaj_gui_priebeh(nazov_konfiguracie: str, seed: int, priebeh: list, nazov_agenta: str = "smart"):
    """Pridá priebeh (deň po dni) jedného behu spusteného cez --gui do gui_priebeh.csv."""
    riadky = [{"konfiguracia": nazov_konfiguracie, "agent": nazov_agenta, "seed": seed, **r}
              for r in priebeh]
    return pripoj_riadky_csv("gui_priebeh.csv", riadky)


def vypis_tabulku(suhrn):
    """Vypíše súhrn experimentu ako tabuľku do konzoly."""
    print(f"\n{'konfigurácia':<13}{'agent':<10}{'skóre (priemer ± sd)':<24}{'úroda':>8}{'voda':>8}"
          f"{'zlé dni':>9}{'sparenia':>9}{'nádrž dní':>10}{'čas ms':>8}")
    for r in suhrn:
        zle_dni = r["dni_sucha_priemer"] + r["dni_prelievania_priemer"]
        print(f"{r['konfiguracia']:<13}{r['agent']:<10}"
              f"{r['skore_priemer']:>8.0f} ± {r['skore_sd']:<12.0f}"
              f"{r['uroda_priemer']:>8.0f}{r['voda_priemer']:>8.0f}{zle_dni:>9.0f}"
              f"{r['dni_sparenia_priemer']:>9.0f}{r['den_vycerpania_nadrze_priemer']:>10.0f}"
              f"{r['cas_ms_priemer']:>8.1f}")
