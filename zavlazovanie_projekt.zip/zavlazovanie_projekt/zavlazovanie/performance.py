"""
Miera úspešnosti ohodnotí výsledok celej sezóny jedným číslom. Hodnotí len výsledok
a nie postup, ktorým ho agent dosiahol:

    skóre = úroda - W1 * voda - W2 * (dni sucha + dni prelievania + dni obarenia)
"""

W1 = 0.2   # cena jedného litra vody v bodoch
W2 = 1.0   # cena jedného zlého dňa (zóna, deň) v bodoch


def skore(vysledky: dict, w1: float = W1, w2: float = W2) -> float:
    """Vypočíta skóre zo súhrnných výsledkov sezóny."""
    zle_dni = (vysledky["dni_sucha"] + vysledky["dni_prelievania"]
               + vysledky.get("dni_sparenia", 0))
    return vysledky["uroda"] - w1 * vysledky["voda"] - w2 * zle_dni
