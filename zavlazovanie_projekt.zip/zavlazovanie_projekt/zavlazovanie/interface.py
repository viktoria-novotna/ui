"""
Dátové typy, cez ktoré si agent a zvyšok programu vymieňajú informácie. Agent smie
poznať len tieto tri veci a nič iné:

  * Percept   - vnem, ktorý pre agenta každý deň vyrobia senzory,
  * Action    - jedna akcia agenta (zaliať zónu danou úrovňou),
  * AgentInfo - údaje, ktoré agent pozná vopred a dostane ich pri vytvorení.

Agent nesmie pristupovať k internému stavu prostredia. Preto sú Percept aj AgentInfo
nemenné (`frozen`) a ich slovníky sú zabalené do MappingProxyType. Senzory vytvárajú
vnem vždy nanovo z nameraných hodnôt, takže ide o kópiu a nie o referenciu na prostredie.
Zápis do vnemu skončí chybou TypeError.
"""

import types
from dataclasses import dataclass, field
from typing import Dict, Mapping, Tuple

Zona = Tuple[int, int]   # (riadok, stĺpec)
Uroven = str             # "malo" alebo "vela"


@dataclass(frozen=True)
class Percept:
    """Čo agent v daný deň vidí. Slovník `vlhkost` obsahuje len zóny so senzorom
    a je nemenná kópia nameraných hodnôt, nie referencia na stav prostredia."""
    den: int
    teplota: float
    dazd: bool
    nadrz: float
    vlhkost: Mapping[Zona, float] = field(default_factory=lambda: types.MappingProxyType({}))

    def __post_init__(self):
        # Zabalí (prípadne ešte nezabalenú) mapu do read-only MappingProxyType,
        # a vytvorí z nej vlastnú kópiu, aby nešlo o cudziu referenciu.
        object.__setattr__(self, "vlhkost", types.MappingProxyType(dict(self.vlhkost)))


@dataclass(frozen=True)
class Action:
    """Jedna akcia agenta: zaliať danú zónu danou úrovňou."""

    zona: Zona
    uroven: Uroven


@dataclass(frozen=True)
class AgentInfo:
    """Informácie, ktoré agent pozná vopred, dané pri jeho vytvorení."""

    rozmer: int
    pocet_dni: int
    zony_so_senzorom: Tuple[Zona, ...]
    min_zdrava: float
    max_zdrava: float
    horuca_teplota: float
    akcie: Mapping[Uroven, Tuple[float, float]]   # úroveň -> (litre, zvýšenie vlhkosti v %)

    def __post_init__(self):
        object.__setattr__(self, "akcie", types.MappingProxyType(dict(self.akcie)))
        object.__setattr__(self, "zony_so_senzorom", tuple(self.zony_so_senzorom))
